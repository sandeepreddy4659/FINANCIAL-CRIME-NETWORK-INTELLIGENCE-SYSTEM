import csv
import math
import re
from bisect import bisect_right
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

import networkx as nx
from flask import Flask, jsonify, request, send_from_directory


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = PROJECT_ROOT / "transactions.csv"
MANUAL_DATA_PATH = PROJECT_ROOT / "manual_transactions.csv"
FRONTEND_PATH = PROJECT_ROOT / "frontend"
REQUIRED_COLUMNS = [
    "Timestamp", "From Bank", "Account", "To Bank", "Account.1",
    "Amount Received", "Receiving Currency", "Amount Paid",
    "Payment Currency", "Payment Format", "Is Laundering",
]
MANUAL_COLUMNS = [column for column in REQUIRED_COLUMNS if column != "Is Laundering"]
RISK_WEIGHTS = {
    "cycle": 40,
    "fan_in": 25,
    "fan_out": 25,
    "connected_pass_through": 20,
    "rapid_pass_through": 20,
    "repeated_relationship": 15,
    "high_amount": 15,
}
REVIEW_THRESHOLD = 40
HISTORICAL_PERCENTILE = 0.95
MIN_CONNECTION_THRESHOLD = 5

app = Flask(__name__, static_folder=str(FRONTEND_PATH), static_url_path="")


def number(value):
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def timestamp(value):
    for pattern in ("%Y/%m/%d %H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M"):
        try:
            return datetime.strptime(value, pattern)
        except (TypeError, ValueError):
            continue
    return None


def submitted_timestamp(value):
    value = str(value).strip()
    if not re.fullmatch(r"\d{2}-\d{2}-\d{4} (?:0[1-9]|1[0-2]):[0-5]\d (?:AM|PM)", value):
        return None
    try:
        return datetime.strptime(value, "%d-%m-%Y %I:%M %p")
    except ValueError:
        return None


def amount(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def load_data():
    """Load the supplied CSV once and add graph-friendly values."""
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Dataset not found: {DATA_PATH}")
    rows = []

    def append_rows(reader, labelled):
        expected_columns = REQUIRED_COLUMNS if labelled else MANUAL_COLUMNS
        missing = [column for column in expected_columns if column not in (reader.fieldnames or [])]
        if missing:
            raise ValueError(f"Required columns are missing: {', '.join(missing)}")
        for source in reader:
            row = {column: source.get(column, "") or "" for column in REQUIRED_COLUMNS}
            label = str(row["Is Laundering"]).strip()
            row["_laundering"] = int(label) if labelled and label in ("0", "1") else None
            row["transaction_id"] = len(rows) + 1
            row["_timestamp"] = timestamp(row["Timestamp"])
            row["_amount_received"] = number(row["Amount Received"])
            row["_amount_paid"] = number(row["Amount Paid"])
            row["Sender"] = f"{row['From Bank']}_{row['Account']}"
            row["Receiver"] = f"{row['To Bank']}_{row['Account.1']}"
            rows.append(row)

    with DATA_PATH.open("r", newline="", encoding="utf-8-sig") as file:
        append_rows(csv.DictReader(file), labelled=True)
    if MANUAL_DATA_PATH.exists():
        with MANUAL_DATA_PATH.open("r", newline="", encoding="utf-8-sig") as file:
            append_rows(csv.DictReader(file), labelled=False)
    return rows


def build_graph(rows):
    graph = nx.DiGraph()
    for row in rows:
        sender, receiver = row["Sender"], row["Receiver"]
        if graph.has_edge(sender, receiver):
            edge = graph[sender][receiver]
            edge["transaction_count"] += 1
            edge["total_amount"] += row["_amount_received"]
        else:
            graph.add_edge(sender, receiver, transaction_count=1,
                           total_amount=row["_amount_received"])
    return graph


def build_features(graph):
    features = {}
    for account in graph.nodes:
        incoming = list(graph.predecessors(account))
        outgoing = list(graph.successors(account))
        features[account] = {
            "incoming_connections": len(incoming),
            "outgoing_connections": len(outgoing),
            "total_connections": len(incoming) + len(outgoing),
            "incoming_amount": sum(graph[source][account]["total_amount"] for source in incoming),
            "outgoing_amount": sum(graph[account][target]["total_amount"] for target in outgoing),
        }
    return features


DATA = load_data()
GRAPH = build_graph(DATA)
FEATURES = build_features(GRAPH)


def percentile(values, fraction, default=0):
    if not values:
        return default
    ordered = sorted(values)
    return ordered[min(int((len(ordered) - 1) * fraction), len(ordered) - 1)]


def score_row(row, graph, features, incoming_threshold, outgoing_threshold,
              relationship_threshold, amount_threshold, cycle_components=None,
              history=None, include_candidate=False):
    sender, receiver = row["Sender"], row["Receiver"]
    history = DATA if history is None else history
    empty = {"incoming_connections": 0, "outgoing_connections": 0}
    sender_features = dict(features.get(sender, empty))
    receiver_features = dict(features.get(receiver, empty))
    new_relationship = include_candidate and not graph.has_edge(sender, receiver)
    if new_relationship:
        sender_features["outgoing_connections"] += 1
        receiver_features["incoming_connections"] += 1
    endpoint_connectivity = {
        "sender": {
            "incoming_connections": sender_features["incoming_connections"],
            "outgoing_connections": sender_features["outgoing_connections"],
        },
        "receiver": {
            "incoming_connections": receiver_features["incoming_connections"],
            "outgoing_connections": receiver_features["outgoing_connections"],
        },
    }
    reasons, structural_signal, cycle_signal, score = [], False, False, 0
    if cycle_components is None:
        same_cycle = sender == receiver or (
            sender in graph and receiver in graph and nx.has_path(graph, receiver, sender))
    else:
        same_cycle = sender == receiver or (
            sender in cycle_components and cycle_components.get(sender) == cycle_components.get(receiver))
    if same_cycle:
        reasons.append("Adding this directed transfer creates a cycle because a path already exists from receiver to sender.")
        cycle_signal, score = True, score + RISK_WEIGHTS["cycle"]

    if sender_features["outgoing_connections"] >= outgoing_threshold:
        reasons.append("Sender is connected to an unusually large number of distinct receiver accounts.")
        structural_signal, score = True, score + RISK_WEIGHTS["fan_out"]
    if receiver_features["incoming_connections"] >= incoming_threshold:
        reasons.append("Receiver is connected to an unusually large number of distinct sender accounts.")
        structural_signal, score = True, score + RISK_WEIGHTS["fan_in"]

    pass_through = any(feature["incoming_connections"] >= incoming_threshold
                       and feature["outgoing_connections"] >= outgoing_threshold
                       for feature in (sender_features, receiver_features))
    if pass_through:
        reasons.append("A transaction endpoint has unusually high incoming and outgoing connectivity, consistent with pass-through activity.")
        structural_signal, score = True, score + RISK_WEIGHTS["connected_pass_through"]

    recent_matched_inflow = False
    transaction_time = row["_timestamp"]
    if transaction_time:
        for previous in history:
            previous_time = previous["_timestamp"]
            if (previous["Receiver"] == sender and previous_time
                    and timedelta(0) <= transaction_time - previous_time <= timedelta(hours=24)
                    and previous["Receiving Currency"].casefold()
                    == row["Payment Currency"].casefold()
                    and abs(previous["_amount_received"] - row["_amount_paid"])
                    <= max(0.01, row["_amount_paid"] * 0.1)):
                recent_matched_inflow = True
                break
    if recent_matched_inflow:
        reasons.append("Sender received a similar amount in the same currency within the previous 24 hours, a possible rapid pass-through pattern.")
        structural_signal, score = True, score + RISK_WEIGHTS["rapid_pass_through"]

    relationship_count = graph[sender][receiver]["transaction_count"] if graph.has_edge(sender, receiver) else 0
    if include_candidate:
        relationship_count += 1
    if relationship_count >= relationship_threshold:
        reasons.append(f"Sender and receiver have an unusually frequent transaction relationship ({relationship_count} records).")
        structural_signal, score = True, score + RISK_WEIGHTS["repeated_relationship"]
    if row["_amount_received"] >= amount_threshold and amount_threshold > 0:
        reasons.append("Transaction amount is in the historical highest 5%; amount alone does not trigger review.")
        score += RISK_WEIGHTS["high_amount"]

    detection_result = ("Requires Review" if structural_signal and score >= REVIEW_THRESHOLD else
                        "No Configured Suspicious Indicator Detected")
    if detection_result == "Requires Review":
        assessment_status = "Potentially Suspicious — Requires Review"
    elif reasons:
        assessment_status = "Indicators Detected — Below Review Threshold"
    else:
        assessment_status = "No Configured Suspicious Indicators Detected"
    if detection_result == "Requires Review":
        explanation = "One or more structural indicators were detected and the rule-based score reached the 40-point review threshold. This is an investigation lead, not confirmation of fraud."
    elif reasons:
        explanation = "Indicators were detected, but the structural review threshold was not met. A cycle or high amount alone does not trigger review."
    else:
        explanation = "No configured graph or transaction indicator was detected from the available history; this does not prove the transaction is legitimate."
    return {
        "detection_result": detection_result,
        "detection_status": assessment_status,
        "assessment_status": assessment_status,
        "risk_score": min(score, 100),
        "detection_reason": reasons,
        "indicators_detected": reasons,
        "explanation": explanation,
        "graph_indicator_detected": structural_signal or cycle_signal,
        "endpoint_connectivity": endpoint_connectivity,
    }


def graph_thresholds(graph, features, rows):
    incoming_threshold = max(MIN_CONNECTION_THRESHOLD, percentile(
        [feature["incoming_connections"] for feature in features.values()], HISTORICAL_PERCENTILE, MIN_CONNECTION_THRESHOLD))
    outgoing_threshold = max(MIN_CONNECTION_THRESHOLD, percentile(
        [feature["outgoing_connections"] for feature in features.values()], HISTORICAL_PERCENTILE, MIN_CONNECTION_THRESHOLD))
    relationship_threshold = max(MIN_CONNECTION_THRESHOLD, percentile(
        [edge["transaction_count"] for _, _, edge in graph.edges(data=True)], HISTORICAL_PERCENTILE, MIN_CONNECTION_THRESHOLD))
    amount_threshold = percentile([row["_amount_received"] for row in rows], HISTORICAL_PERCENTILE, 0)
    return incoming_threshold, outgoing_threshold, relationship_threshold, amount_threshold


def assess_transactions():
    """Score transactions from graph/amount signals, never from dataset labels."""
    global DETECTIONS, INCOMING_THRESHOLD, OUTGOING_THRESHOLD, RELATIONSHIP_THRESHOLD, AMOUNT_THRESHOLD
    INCOMING_THRESHOLD, OUTGOING_THRESHOLD, RELATIONSHIP_THRESHOLD, AMOUNT_THRESHOLD = graph_thresholds(GRAPH, FEATURES, DATA)
    DETECTIONS = {}
    cycle_components = {account: component_id
                        for component_id, component in enumerate(nx.strongly_connected_components(GRAPH))
                        for account in component}
    for row in DATA:
        DETECTIONS[row["transaction_id"]] = score_row(
            row, GRAPH, FEATURES, INCOMING_THRESHOLD, OUTGOING_THRESHOLD,
            RELATIONSHIP_THRESHOLD, AMOUNT_THRESHOLD, cycle_components)


assess_transactions()
EVALUATION_CACHE = None


def refresh_data():
    global DATA, GRAPH, FEATURES
    DATA = load_data()
    GRAPH = build_graph(DATA)
    FEATURES = build_features(GRAPH)
    assess_transactions()
    global EVALUATION_CACHE
    EVALUATION_CACHE = None


def records(rows):
    result = []
    for row in rows:
        output = {column: row[column] for column in REQUIRED_COLUMNS}
        if row["_timestamp"]:
            output["Timestamp"] = row["_timestamp"].strftime("%Y-%m-%d %H:%M")
        output["Amount Received"] = row["_amount_received"]
        output["Amount Paid"] = row["_amount_paid"]
        output["Is Laundering"] = row["_laundering"]
        output["transaction_id"] = row["transaction_id"]
        output.update(DETECTIONS[row["transaction_id"]])
        result.append(output)
    return result


def amount_distribution():
    amounts = [row["_amount_received"] for row in DATA if row["_amount_received"] > 0]
    if not amounts:
        return []
    minimum, maximum = min(amounts), max(amounts)
    if minimum == maximum:
        return [{"label": f"{minimum:,.0f}", "count": len(amounts)}]
    lower, upper = math.floor(math.log10(minimum)), math.ceil(math.log10(maximum))
    edges = [10 ** (lower + step * (upper - lower) / 12) for step in range(13)]
    counts = [0] * 12
    for amount in amounts:
        bucket = min(max(bisect_right(edges, amount) - 1, 0), 11)
        counts[bucket] += 1
    return [{"label": f"{edges[index]:,.0f}-{edges[index + 1]:,.0f}", "count": counts[index]}
            for index in range(12)]


def get_summary():
    known_labels = [row["_laundering"] for row in DATA if row["_laundering"] is not None]
    laundering = sum(known_labels)
    dated = [row for row in DATA if row["_timestamp"]]
    trend = Counter(row["_timestamp"].strftime("%Y-%m-%d") for row in dated)
    amounts = [row["_amount_received"] for row in DATA]
    return {
        "total_transactions": len(DATA),
        "labelled_transactions": len(known_labels),
        "unlabelled_transactions": len(DATA) - len(known_labels),
        "total_accounts": GRAPH.number_of_nodes(),
        "total_graph_connections": GRAPH.number_of_edges(),
        "laundering_transactions": laundering,
        "non_laundering_transactions": len(known_labels) - laundering,
        "laundering_percentage": round((laundering / len(known_labels)) * 100, 2) if known_labels else 0,
        "average_amount": round(sum(amounts) / len(amounts), 2) if amounts else 0,
        "maximum_amount": round(max(amounts), 2) if amounts else 0,
        "amount_distribution": amount_distribution(),
        "transactions_over_time": [{"date": date, "count": count} for date, count in sorted(trend.items())],
    }


def get_network():
    top_accounts = [{"account": account, **feature} for account, feature in FEATURES.items()]
    top_accounts.sort(key=lambda item: item["total_connections"], reverse=True)
    return {"nodes": GRAPH.number_of_nodes(), "edges": GRAPH.number_of_edges(),
            "top_accounts": top_accounts[:10], "total_connections": GRAPH.number_of_edges()}


def get_suspicious_accounts():
    maximum_connections = max((item["total_connections"] for item in FEATURES.values()), default=1)
    maximum_amount = max((item["incoming_amount"] + item["outgoing_amount"] for item in FEATURES.values()), default=1)
    result = []
    for account, feature in FEATURES.items():
        total_amount = feature["incoming_amount"] + feature["outgoing_amount"]
        result.append({
            "account": account,
            "incoming_connections": feature["incoming_connections"],
            "outgoing_connections": feature["outgoing_connections"],
            "total_connections": feature["total_connections"],
            "incoming_amount": round(feature["incoming_amount"], 2),
            "outgoing_amount": round(feature["outgoing_amount"], 2),
            "investigation_score": round(feature["total_connections"] / maximum_connections * 60
                                         + total_amount / maximum_amount * 40, 1),
            "indicator": "Review",
        })
    return sorted(result, key=lambda item: item["investigation_score"], reverse=True)[:20]


def get_evaluation():
    """Evaluate rules on a chronological holdout using only the earlier graph."""
    global EVALUATION_CACHE
    if EVALUATION_CACHE is not None:
        return EVALUATION_CACHE
    ordered = sorted((row for row in DATA if row["_timestamp"] and row["_laundering"] is not None),
                     key=lambda row: (row["_timestamp"], row["transaction_id"]))
    if len(ordered) < 2:
        return {"available": False, "total_evaluated": 0,
                "message": "At least two timestamped transactions are needed for holdout evaluation."}
    split = min(max(int(len(ordered) * 0.8), 1), len(ordered) - 1)
    training_rows, holdout_rows = ordered[:split], ordered[split:]
    training_graph = build_graph(training_rows)
    training_features = build_features(training_graph)
    thresholds = graph_thresholds(training_graph, training_features, training_rows)
    incoming_threshold, outgoing_threshold, relationship_threshold, amount_threshold = thresholds
    true_negative = false_positive = false_negative = true_positive = 0
    for row in holdout_rows:
        actual = row["_laundering"]
        assessment = score_row(row, training_graph, training_features, incoming_threshold,
                               outgoing_threshold, relationship_threshold, amount_threshold,
                               history=training_rows, include_candidate=True)
        predicted = int(assessment["detection_result"] == "Requires Review")
        if actual == 0 and predicted == 0:
            true_negative += 1
        elif actual == 0 and predicted == 1:
            false_positive += 1
        elif actual == 1 and predicted == 0:
            false_negative += 1
        else:
            true_positive += 1

    total = true_negative + false_positive + false_negative + true_positive
    accuracy = (true_positive + true_negative) / total if total else 0
    precision_denominator = true_positive + false_positive
    recall_denominator = true_positive + false_negative
    precision = true_positive / precision_denominator if precision_denominator else 0
    recall = true_positive / recall_denominator if recall_denominator else 0
    f1_score = (2 * precision * recall / (precision + recall)) if precision + recall else 0
    EVALUATION_CACHE = {
        "available": True,
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1_score": f1_score,
        "true_negative": true_negative,
        "false_positive": false_positive,
        "false_negative": false_negative,
        "true_positive": true_positive,
        "total_evaluated": total,
        "training_transactions": len(training_rows),
        "holdout_start": holdout_rows[0]["_timestamp"].strftime("%Y-%m-%d %H:%M"),
        "detector": "Label-independent graph rules; chronological 80/20 holdout on known labels only",
    }
    return EVALUATION_CACHE


def get_transaction_details(transaction_id):
    if transaction_id < 1 or transaction_id > len(DATA):
        raise KeyError(transaction_id)
    row = DATA[transaction_id - 1]
    sender, receiver = row["Sender"], row["Receiver"]

    def account_context(account):
        feature = FEATURES[account]
        return {
            "account": account,
            "incoming_connections": feature["incoming_connections"],
            "outgoing_connections": feature["outgoing_connections"],
            "incoming_accounts": sorted(GRAPH.predecessors(account))[:30],
            "outgoing_accounts": sorted(GRAPH.successors(account))[:30],
        }

    nodes = {sender, receiver}
    edges = {(sender, receiver)}
    for endpoint in (sender, receiver):
        for neighbor in list(GRAPH.predecessors(endpoint)) + list(GRAPH.successors(endpoint)):
            if len(nodes) >= 10 and neighbor not in nodes:
                continue
            nodes.add(neighbor)
            edges.add((neighbor, endpoint) if GRAPH.has_edge(neighbor, endpoint) else (endpoint, neighbor))

    cycle_accounts = []
    if sender == receiver and GRAPH.has_edge(sender, sender):
        cycle_accounts = [sender]
    elif sender in GRAPH and receiver in GRAPH and nx.has_path(GRAPH, receiver, sender):
        cycle_accounts = [sender] + nx.shortest_path(GRAPH, receiver, sender)[:-1]
    related = sorted((set(GRAPH.predecessors(sender)) | set(GRAPH.successors(sender))
                      | set(GRAPH.predecessors(receiver)) | set(GRAPH.successors(receiver)))
                     - {sender, receiver})
    return {
        **records([row])[0],
        "sender_details": account_context(sender),
        "receiver_details": account_context(receiver),
        "relevant_connected_accounts": related[:30],
        "cycle_accounts": cycle_accounts,
        "network": {
            "nodes": [{"id": account, "role": "sender" if account == sender else "receiver" if account == receiver else "connected"}
                      for account in sorted(nodes)],
            "edges": [{"source": source, "target": target, "selected": source == sender and target == receiver}
                      for source, target in sorted(edges)],
        },
    }


def get_account_details(account):
    if account not in GRAPH:
        raise KeyError(account)
    incoming_rows = [row for row in DATA if row["Receiver"] == account]
    outgoing_rows = [row for row in DATA if row["Sender"] == account]
    related = [row for row in DATA if row["Sender"] == account or row["Receiver"] == account]
    related.sort(key=lambda row: row["_timestamp"] or datetime.min)
    feature = FEATURES[account]
    connected = sorted(set(GRAPH.predecessors(account)) | set(GRAPH.successors(account)))
    return {
        "account": account,
        "transactions": len(related),
        "incoming": len(incoming_rows),
        "outgoing": len(outgoing_rows),
        "incoming_transactions": feature["incoming_connections"],
        "outgoing_transactions": feature["outgoing_connections"],
        "incoming_amount": round(feature["incoming_amount"], 2),
        "outgoing_amount": round(feature["outgoing_amount"], 2),
        "total_amount": round(feature["incoming_amount"] + feature["outgoing_amount"], 2),
        "connected_accounts": connected[:30],
        "laundering_transactions": sum(row["_laundering"] == 1 for row in related),
        "related_laundering_transactions": sum(row["_laundering"] == 1 for row in related),
        "related_transactions": records(related),
    }


def filter_rows(rows, search="", laundering="all"):
    search = search.strip().lower()
    result = rows
    if search:
        result = [row for row in result if any(search in str(row[column]).lower() for column in REQUIRED_COLUMNS)
              or search in row["Sender"].lower() or search in row["Receiver"].lower()]
    if laundering in ("laundering", "1"):
        result = [row for row in result if row["_laundering"] == 1]
    elif laundering in ("non-laundering", "0"):
        result = [row for row in result if row["_laundering"] == 0]
    return result


@app.get("/api/summary")
def summary():
    return jsonify(get_summary())


@app.get("/api/transactions")
def transactions():
    result = DATA
    account = request.args.get("account", "").strip().lower()
    sender = request.args.get("sender", "").strip().lower()
    receiver = request.args.get("receiver", "").strip().lower()
    bank = request.args.get("bank", "").strip().lower()
    currency = request.args.get("currency", "").strip().lower()
    label = request.args.get("label", request.args.get("status", "all")).lower()
    detection = request.args.get("detection", "all").lower()
    search = request.args.get("search", "").strip().lower()
    if account:
        result = [row for row in result if row["Sender"].lower() == account or row["Receiver"].lower() == account]
    if sender:
        result = [row for row in result if sender in row["Sender"].lower()]
    if receiver:
        result = [row for row in result if receiver in row["Receiver"].lower()]
    if bank:
        result = [row for row in result if row["From Bank"].lower() == bank or row["To Bank"].lower() == bank]
    if currency:
        result = [row for row in result if row["Receiving Currency"].lower() == currency or row["Payment Currency"].lower() == currency]
    if search:
        result = [row for row in result if any(search in str(row[column]).lower() for column in REQUIRED_COLUMNS)
                  or search in row["Sender"].lower() or search in row["Receiver"].lower()]
    try:
        if request.args.get("min_amount"):
            result = [row for row in result if row["_amount_received"] >= float(request.args["min_amount"])]
        if request.args.get("max_amount"):
            result = [row for row in result if row["_amount_received"] <= float(request.args["max_amount"])]
        page = max(int(request.args.get("page", 1)), 1)
        limit = min(max(int(request.args.get("limit", 25)), 1), 100)
    except ValueError:
        return jsonify({"error": "Amount filters must be numbers and page/limit must be whole numbers"}), 400
    start_date, end_date = request.args.get("from_date", ""), request.args.get("to_date", "")
    if start_date:
        result = [row for row in result if row["_timestamp"] and row["_timestamp"].date().isoformat() >= start_date]
    if end_date:
        result = [row for row in result if row["_timestamp"] and row["_timestamp"].date().isoformat() <= end_date]
    result = filter_rows(result, laundering=label)
    if detection in ("review", "requires review"):
        result = [row for row in result if DETECTIONS[row["transaction_id"]]["detection_result"] == "Requires Review"]
    elif detection in ("clear", "no suspicious indicator found", "no configured suspicious indicator detected"):
        result = [row for row in result if DETECTIONS[row["transaction_id"]]["detection_result"] == "No Configured Suspicious Indicator Detected"]
    start = (page - 1) * limit
    return jsonify({"total": len(result), "page": page, "limit": limit,
                    "transactions": records(result[start:start + limit])})


@app.get("/api/transaction/<int:transaction_id>")
def transaction_detail(transaction_id):
    try:
        return jsonify(get_transaction_details(transaction_id))
    except KeyError:
        return jsonify({"error": "Transaction not found"}), 404


@app.get("/api/network")
def network():
    return jsonify(get_network())


@app.get("/api/suspicious")
def suspicious():
    return jsonify({"title": "Accounts Requiring Investigation",
                    "notice": "A high score is an investigation indicator, not proof of money laundering.",
                    "accounts": get_suspicious_accounts()})


@app.get("/api/evaluation")
def evaluation():
    return jsonify(get_evaluation())


@app.get("/api/account/<path:account>")
def account(account):
    try:
        return jsonify(get_account_details(account))
    except KeyError:
        return jsonify({"error": "Account not found"}), 404


@app.post("/api/add-transaction")
def add_transaction():
    payload = request.get_json(silent=True) or request.form.to_dict()
    if not isinstance(payload, dict):
        return jsonify({"success": False, "error": "Transaction data must be a JSON object or form submission."}), 400
    missing = [column for column in MANUAL_COLUMNS if not str(payload.get(column, "")).strip()]
    if missing:
        return jsonify({"success": False, "error": f"Missing required fields: {', '.join(missing)}"}), 400
    if str(payload["Account"]).strip().casefold() == str(payload["Account.1"]).strip().casefold():
        return jsonify({
            "success": False,
            "error": "Transaction rejected: Sender and receiver account numbers must be different."
        }), 400

    parsed_received = amount(payload["Amount Received"])
    parsed_paid = amount(payload["Amount Paid"])
    if (parsed_received is None or parsed_paid is None
            or not math.isfinite(parsed_received) or not math.isfinite(parsed_paid)
            or parsed_received <= 0 or parsed_paid <= 0):
        return jsonify({"success": False, "error": "Amount Paid and Amount Received must be valid positive numbers."}), 400
    if abs(parsed_paid - parsed_received) > 0.01:
        return jsonify({"success": False, "error": "Transaction rejected: Amount Paid and Amount Received must be equal."}), 400
    if str(payload["Payment Currency"]).strip().casefold() != str(payload["Receiving Currency"]).strip().casefold():
        return jsonify({"success": False, "error": "Transaction rejected: Payment Currency and Receiving Currency must be the same."}), 400
    parsed_timestamp = submitted_timestamp(payload["Timestamp"])
    if parsed_timestamp is None:
        return jsonify({"success": False, "error": "Timestamp must be a valid date and time in DD-MM-YYYY HH:MM AM/PM format."}), 400

    row = {column: str(payload[column]).strip() for column in MANUAL_COLUMNS}
    row["Timestamp"] = parsed_timestamp.strftime("%Y/%m/%d %H:%M")
    row["Amount Received"] = str(parsed_received)
    row["Amount Paid"] = str(parsed_paid)
    row.update({
        "Is Laundering": "",
        "transaction_id": len(DATA) + 1,
        "_timestamp": parsed_timestamp,
        "_amount_received": parsed_received,
        "_amount_paid": parsed_paid,
        "_laundering": None,
        "Sender": f"{row['From Bank']}_{row['Account']}",
        "Receiver": f"{row['To Bank']}_{row['Account.1']}",
    })

    def same_transaction(existing):
        if existing["_laundering"] is not None:
            return False
        return all(
            (existing["_timestamp"] == parsed_timestamp if column == "Timestamp" else
             existing["_amount_received"] == parsed_received if column == "Amount Received" else
             existing["_amount_paid"] == parsed_paid if column == "Amount Paid" else
             str(existing[column]).strip() == row[column])
            for column in MANUAL_COLUMNS
        )

    duplicate = next((existing for existing in DATA if same_transaction(existing)), None)

    def success_response(saved_row, assessment, message, is_duplicate):
        transaction = {
            "transaction_id": saved_row["transaction_id"],
            "sender_account": saved_row["Sender"],
            "receiver_account": saved_row["Receiver"],
            "amount": saved_row["_amount_received"],
            "currency": saved_row["Receiving Currency"],
        }
        return jsonify({
            "success": True,
            "saved": True,
            "message": message,
            "transaction_id": saved_row["transaction_id"],
            "transaction": transaction,
            "assessment": {
                "completed": True,
                "status": assessment["assessment_status"],
                "risk_score": assessment["risk_score"],
                "reasons": assessment["indicators_detected"],
                "indicators": assessment["indicators_detected"],
                "explanation": assessment["explanation"],
                "detection_result": assessment["detection_result"],
                "endpoint_connectivity": assessment["endpoint_connectivity"],
            },
            "duplicate": is_duplicate,
            "detector": "Transparent NetworkX graph and transaction rules; risk score is not a model probability.",
        })

    if duplicate:
        assessment = DETECTIONS[duplicate["transaction_id"]]
        return success_response(
            duplicate, assessment,
            "This transaction was already saved; it was not added again.", True)

    try:
        assessment = score_row(
            row, GRAPH, FEATURES, INCOMING_THRESHOLD, OUTGOING_THRESHOLD,
            RELATIONSHIP_THRESHOLD, AMOUNT_THRESHOLD, history=DATA, include_candidate=True)
    except (nx.NetworkXException, KeyError, TypeError, ValueError, ArithmeticError):
        app.logger.exception("Could not assess the proposed transaction")
        return jsonify({
            "success": False,
            "saved": False,
            "error": "The transaction could not be assessed and was not saved.",
        }), 500

    try:
        with DATA_PATH.open("a", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=REQUIRED_COLUMNS)
            writer.writerow({column: row[column] for column in REQUIRED_COLUMNS})
    except OSError:
        app.logger.exception("Could not append the transaction to the dataset")
        return jsonify({
            "success": False,
            "saved": False,
            "error": "The transaction could not be saved. Check the dataset file and try again.",
        }), 500
    try:
        refresh_data()
    except (OSError, ValueError, nx.NetworkXException, KeyError, TypeError, ArithmeticError):
        app.logger.exception("Transaction was saved, but the graph could not be refreshed")
        return jsonify({
            "success": False,
            "saved": True,
            "transaction_id": row["transaction_id"],
            "error": "The transaction was saved, but the graph could not be refreshed. Check Transactions; do not submit it again.",
        }), 500
    DETECTIONS[row["transaction_id"]] = assessment
    return success_response(row, assessment, "Transaction added successfully", False)


@app.get("/api/dataset")
def dataset():
    try:
        page = max(int(request.args.get("page", 1)), 1)
        limit = min(max(int(request.args.get("limit", 25)), 1), 100)
    except ValueError:
        return jsonify({"error": "page and limit must be whole numbers"}), 400
    result = filter_rows(DATA, request.args.get("search", ""), request.args.get("laundering", "all").lower())
    sort_column = request.args.get("sort", "Timestamp")
    reverse = request.args.get("direction", "asc") == "desc"
    sort_keys = {"Timestamp": lambda row: row["_timestamp"] or datetime.min,
                 "Amount Received": lambda row: row["_amount_received"],
                 "Is Laundering": lambda row: (row["_laundering"] is None, row["_laundering"] or 0)}
    if sort_column in sort_keys:
        result = sorted(result, key=sort_keys[sort_column], reverse=reverse)
    start = (page - 1) * limit
    return jsonify({
        "rows": len(DATA), "total": len(result), "page": page, "limit": limit,
        "columns": REQUIRED_COLUMNS, "shape": [len(DATA), len(REQUIRED_COLUMNS)],
        "missing_values": sum(not row[column] for row in DATA for column in REQUIRED_COLUMNS),
        "records": records(result[start:start + limit]),
    })


@app.get("/api/accounts")
def accounts():
    return jsonify(sorted(GRAPH.nodes))


@app.get("/")
def index():
    return send_from_directory(FRONTEND_PATH, "index.html")


@app.errorhandler(FileNotFoundError)
@app.errorhandler(ValueError)
def data_error(error):
    return jsonify({"success": False, "error": str(error)}), 500


@app.errorhandler(500)
def internal_error(_error):
    return jsonify({"success": False, "error": "An unexpected server error occurred."}), 500


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)