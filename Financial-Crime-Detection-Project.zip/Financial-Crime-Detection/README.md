# Financial Crime Network Detection Using Graph Analytics

This college project explores the supplied transaction data and highlights graph patterns that may require investigation. It uses the existing `transactions.csv`; newly submitted transactions are appended with an unknown laundering label, and no synthetic data or database is used.

## Architecture

The project has a short frontend/backend split:

- `backend/app.py` loads the CSV, builds the NetworkX directed graph, calculates indicators, and exposes Flask JSON APIs.
- `frontend/index.html`, `style.css`, and `script.js` provide the responsive dashboard and call the APIs with `fetch()`.
- New transactions must use `DD-MM-YYYY HH:MM AM/PM`, have different account numbers, positive equal amounts (within 0.01), and matching currencies. Valid timestamps are converted to the CSV's existing format, and the laundering label remains blank because it is unknown.

## Dataset

The expected 11 columns are `Timestamp`, `From Bank`, `Account`, `To Bank`, `Account.1`, `Amount Received`, `Receiving Currency`, `Amount Paid`, `Payment Currency`, `Payment Format`, and `Is Laundering`.

## Technologies

- Python, Flask
- Python's built-in `csv` module for loading and filtering the CSV
- NetworkX for directed graph analytics
- HTML, CSS, vanilla JavaScript, and Chart.js via CDN

## Graph construction

Each account node is identified by combining its bank and account value:

```text
sender = From Bank + "_" + Account
receiver = To Bank + "_" + Account.1
```

Each CSV row adds a directed edge from sender to receiver. Repeated sender-receiver pairs are aggregated with transaction count and total amount. The UI renders only a selected account's local network, never the full graph.

## API endpoints

- `GET /api/summary` returns headline transaction and graph metrics.
- `GET /api/transactions` returns stable row IDs, rule-based assessments, and paginated results; filters include detection result, dataset label, account, bank, amount, currency, search, and date range.
- `GET /api/transaction/<transaction_id>` returns one transaction's assessment, endpoint connections, relevant accounts, detected cycle, and a small local network.
- `GET /api/network` returns graph size and the top connected accounts.
- `GET /api/suspicious` returns the top 20 accounts requiring investigation.
- `GET /api/evaluation` evaluates label-independent rules on a chronological 80/20 holdout, using only the earlier transactions to build the reference graph and thresholds.
- `GET /api/account/<account>` returns one account's activity, relationships, and related labelled records.
- `GET /api/dataset` returns shape, columns, missing-value count, and a paginated view of the real CSV.

## Transaction assessment

The `Is Laundering` value is shown only as the actual dataset label and is never used by the detector. Newly submitted transactions are assessed against the graph and history before their row is appended. Rules check for a path from receiver back to sender (a directed cycle), unusually high directional fan-in or fan-out, a highly connected pass-through endpoint, an unusually frequent sender/receiver relationship, and a sender receiving a similar amount in the same currency within the previous 24 hours. The amount's historical top-five-percentile status contributes 15 points but cannot trigger review by itself.

The configurable `RISK_WEIGHTS` in `backend/app.py` assign points as follows: directed cycle (40), high fan-in (25), high fan-out (25), high connectivity in both directions at an endpoint (20), recent matched inflow/pass-through (20), repeated relationship (15), and high amount (15), capped at 100. Fan-in, fan-out, and repeated-relationship thresholds are the greater of 5 or the historical 95th percentile. High amount is the historical 95th percentile. A recent matched inflow means the sender received a similar amount (within 10%) in the same currency during the preceding 24 hours. A transaction requires review only when a structural indicator other than a cycle is present and the total reaches `REVIEW_THRESHOLD` (40). Thus neither a cycle alone nor a high amount alone triggers review. The UI lists only detected indicators and their explanations. These are transparent investigation rules, not proof of wrongdoing; the score is not a probability.

No trained transaction-level classifier is present or runnable in this project environment (scikit-learn is not installed). Detection uses NetworkX and the documented rules; it does not claim model predictions or probabilities.

Evaluation uses only timestamped transactions with known `Is Laundering` labels from the supplied CSV. The first 80% form a chronological reference period. The graph and amount/connectivity thresholds are built from that period; predictions for the later 20% are then compared with their actual labels. Unlabelled manually added transactions are excluded from both training/reference and evaluation, and predictions are never used as ground-truth labels. Scikit-learn is not required; this project uses transparent graph-based rules, not a supervised classifier. These holdout metrics describe this rule set and are not a substitute for prospective validation.

## Install and run

Open the VS Code terminal in this folder and run:

```powershell
python -m pip install -r requirements.txt
python backend/app.py
```

Open `http://127.0.0.1:5000` in a browser. The sidebar provides Dashboard, Dataset, Transactions, Network Analysis, Suspicious Accounts, Evaluation, and Account Investigation views.
