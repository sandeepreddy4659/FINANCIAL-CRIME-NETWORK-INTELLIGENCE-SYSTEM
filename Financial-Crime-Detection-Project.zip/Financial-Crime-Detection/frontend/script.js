const $ = (id) => document.getElementById(id);
const charts = {};
const fmt = (value) => Number(value || 0).toLocaleString();
const money = (value) => Number(value || 0).toLocaleString(undefined, {maximumFractionDigits: 2});
const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, character => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[character]));

async function api(path, options) {
  const response = await fetch(path, options);
  let body = null;
  try { body = await response.json(); } catch { body = null; }
  if (!response.ok) throw new Error(body?.error || 'Request failed');
  return body;
}
function showError(error) { $('alert').textContent = error.message; $('alert').classList.remove('hidden'); }
function hideError() { $('alert').classList.add('hidden'); }
function table(headers, rows) { if (!rows.length) return '<p class="muted">No records found.</p>'; return `<div class="table-wrap"><table><thead><tr>${headers.map((h) => `<th>${escapeHTML(h.label)}</th>`).join('')}</tr></thead><tbody>${rows.map(row => `<tr>${headers.map(h => `<td>${h.render ? h.render(row[h.key], row) : escapeHTML(row[h.key] ?? '—')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`; }
function draw(id, config) { if (charts[id]) charts[id].destroy(); charts[id] = new Chart($(id), config); }
function chartDefaults() { return {color:'#8ca0ae', font:{family:'DM Sans'}, responsive:true, maintainAspectRatio:false}; }

async function loadDashboard() {
  const [summary, network] = await Promise.all([api('/api/summary'), api('/api/network')]);
  $('metric-transactions').textContent = fmt(summary.total_transactions); $('metric-accounts').textContent = fmt(summary.total_accounts); $('metric-connections').textContent = fmt(summary.total_graph_connections); $('metric-laundering').textContent = fmt(summary.laundering_transactions); $('metric-laundering-rate').textContent = `${summary.laundering_percentage}% of labelled transactions`;
  const labels = {color:'#8ca0ae', font:{family:'DM Sans'}};
  draw('label-chart',{type:'doughnut',data:{labels:['Non-laundering','Laundering','Unknown label'],datasets:[{data:[summary.non_laundering_transactions,summary.laundering_transactions,summary.unlabelled_transactions],backgroundColor:['#294757','#f3b562','#7eb5ff'],borderWidth:0}]},options:{...chartDefaults(),plugins:{legend:{position:'bottom',labels}}}});
  const bins = summary.amount_distribution; draw('amount-chart',{type:'bar',data:{labels:bins.map(b=>b.label),datasets:[{data:bins.map(b=>b.count),backgroundColor:'#45d6c5',borderRadius:3}]},options:{...chartDefaults(),plugins:{legend:{display:false},tooltip:{callbacks:{title:items=>`Amount range: ${items[0].label}`}}},scales:{x:{grid:{display:false},ticks:{maxRotation:45,minRotation:35}},y:{grid:{color:'#243544'},beginAtZero:true}}}});
  const trend = summary.transactions_over_time; draw('time-chart',{type:'line',data:{labels:trend.map(item=>item.date),datasets:[{data:trend.map(item=>item.count),borderColor:'#7eb5ff',backgroundColor:'rgba(126,181,255,.12)',fill:true,tension:.35,pointRadius:1}]},options:{...chartDefaults(),plugins:{legend:{display:false}},scales:{x:{grid:{display:false},ticks:{maxTicksLimit:10}},y:{grid:{color:'#243544'},beginAtZero:true}}}});
  draw('top-chart',{type:'bar',data:{labels:network.top_accounts.slice(0,8).map(a=>a.account),datasets:[{data:network.top_accounts.slice(0,8).map(a=>a.total_connections),backgroundColor:'#45d6c5',borderRadius:3}]},options:{indexAxis:'y',...chartDefaults(),plugins:{legend:{display:false}},scales:{x:{grid:{color:'#243544'}},y:{grid:{display:false}}}}});
}
const datasetState={page:1,limit:25};
async function loadDataset(){const params=new URLSearchParams({page:datasetState.page,limit:datasetState.limit,search:$('dataset-search').value,laundering:$('dataset-laundering').value,sort:$('dataset-sort').value,direction:$('dataset-direction').value});const d=await api(`/api/dataset?${params}`);const pages=Math.max(Math.ceil(d.total/d.limit),1);if(d.page>pages){datasetState.page=pages;return loadDataset()}$('dataset-rows').textContent=fmt(d.rows);$('dataset-columns').textContent=d.columns.length;$('dataset-missing').textContent=fmt(d.missing_values);$('column-list').innerHTML=d.columns.map(c=>`<span class="tag">${c}</span>`).join('');$('dataset-count').textContent=`${fmt(d.total)} matching records`;$('dataset-page').textContent=`Page ${d.page} of ${pages}`;$('dataset-previous').disabled=d.page===1;$('dataset-next').disabled=d.page>=pages;$('dataset-table').innerHTML=table(d.columns.map(c=>c==='Is Laundering'?{key:c,label:c,render:value=>value==null?'Unknown (not labelled)':value}:{key:c,label:c}),d.records)}
const transactionState={page:1,limit:25,total:0};
function transactionLabel(row){return row['Is Laundering']===''||row['Is Laundering']==null?'Unknown (not labelled)':Number(row['Is Laundering'])===1?'Laundering-labelled (1)':'Non-laundering-labelled (0)'}
function transactionHeaders(){return [{key:'Timestamp',label:'Timestamp'},{key:'From Bank',label:'From bank'},{key:'Account',label:'Sender account'},{key:'To Bank',label:'To bank'},{key:'Account.1',label:'Receiver account'},{key:'Amount Received',label:'Amount received',render:money},{key:'Is Laundering',label:'Actual dataset label',render:(_,row)=>transactionLabel(row)},{key:'detection_result',label:'Detection result'},{key:'risk_score',label:'Risk score',render:value=>`${value}/100`}]}
function renderTransactionTable(rows){if(!rows.length)return '<p class="muted">No records found.</p>';return `<div class="table-wrap"><table><thead><tr><th>Timestamp</th><th>Sender account</th><th>Receiver account</th><th>Amount</th><th>Actual dataset label</th><th>Detection result</th><th>Risk score</th><th>Detection reason</th></tr></thead><tbody>${rows.map(row=>{const sender=`${row['From Bank']}_${row.Account}`,receiver=`${row['To Bank']}_${row['Account.1']}`,label=transactionLabel(row),reason=(row.detection_reason||[]).join(' ');return `<tr class="transaction-row" data-id="${row.transaction_id}"><td><button class="transaction-select" data-id="${row.transaction_id}" type="button">${escapeHTML(row.Timestamp)}</button></td><td>${escapeHTML(sender)}</td><td>${escapeHTML(receiver)}</td><td>${money(row['Amount Received'])}</td><td>${escapeHTML(label)}</td><td><span class="${row.detection_result==='Requires Review'?'review':'clear-status'}">${escapeHTML(row.detection_result)}</span></td><td>${row.risk_score}/100</td><td class="reason-cell">${escapeHTML(reason||'—')}</td></tr>`}).join('')}</tbody></table></div>`}
async function loadTransactions(){const params=new URLSearchParams({page:transactionState.page,limit:transactionState.limit});[['search','filter-search'],['detection','filter-detection'],['label','filter-status'],['account','filter-account'],['sender','filter-sender'],['receiver','filter-receiver'],['bank','filter-bank'],['currency','filter-currency'],['min_amount','filter-min'],['max_amount','filter-max'],['from_date','filter-from-date'],['to_date','filter-to-date']].forEach(([key,id])=>{if($(id).value)params.set(key,$(id).value)});const data=await api(`/api/transactions?${params}`);const pages=Math.max(Math.ceil(data.total/data.limit),1);if(data.page>pages){transactionState.page=pages;return loadTransactions()}transactionState.total=data.total;$('transaction-count').textContent=`${fmt(data.total)} matching transactions`;$('transaction-page').textContent=`Page ${data.page} of ${pages}`;$('transaction-previous').disabled=data.page===1;$('transaction-next').disabled=data.page>=pages;$('transaction-table').innerHTML=renderTransactionTable(data.transactions)}
function renderTransactionNetwork(network){const nodes=network.nodes||[],edges=network.edges||[];if(!nodes.length)return '';const sender=nodes.find(node=>node.role==='sender')?.id,receiver=nodes.find(node=>node.role==='receiver')?.id,positions=new Map();positions.set(sender,{x:155,y:105});positions.set(receiver,{x:465,y:105});const connected=nodes.filter(node=>node.id!==sender&&node.id!==receiver);connected.forEach((node,index)=>{const angle=(index/Math.max(connected.length,1))*Math.PI*2;positions.set(node.id,{x:310+135*Math.cos(angle),y:105+75*Math.sin(angle)})});return `<svg class="transaction-network" viewBox="0 0 620 210" role="img" aria-label="Selected transaction and nearby accounts"><defs><marker id="transaction-arrow" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0,0 L0,6 L8,3 z" fill="#688091"></path></marker></defs>${edges.map(edge=>{const from=positions.get(edge.source),to=positions.get(edge.target);return from&&to?`<line x1="${from.x}" y1="${from.y}" x2="${to.x}" y2="${to.y}" class="${edge.selected?'selected-edge':''}" marker-end="url(#transaction-arrow)"></line>`:''}).join('')}${nodes.map(node=>{const point=positions.get(node.id),role=node.role;return `<g class="${role}"><circle cx="${point.x}" cy="${point.y}" r="${role==='connected'?8:13}"></circle><text x="${point.x}" y="${point.y+27}" text-anchor="middle">${escapeHTML(node.id)}</text></g>`}).join('')}</svg>`}
function renderTransactionDetail(detail){const accountBlock=(title,account)=>`<div class="endpoint-detail"><h4>${title}: ${escapeHTML(account.account)}</h4><p>${account.incoming_connections} distinct incoming · ${account.outgoing_connections} distinct outgoing</p><div><strong>Incoming from</strong><span>${escapeHTML(account.incoming_accounts.join(', ')||'None')}</span></div><div><strong>Outgoing to</strong><span>${escapeHTML(account.outgoing_accounts.join(', ')||'None')}</span></div></div>`;const reasons=detail.detection_reason||[];const cycle=detail.cycle_accounts||[];return `<div class="panel-heading"><div><h3>Transaction #${detail.transaction_id}</h3><p>${escapeHTML(detail.Timestamp)} · ${money(detail['Amount Received'])} ${escapeHTML(detail['Receiving Currency'])} · Dataset label: ${transactionLabel(detail)}</p></div><button id="close-transaction-detail" class="secondary-btn" type="button">Close</button></div><div class="transaction-summary"><span class="${detail.detection_result==='Requires Review'?'review':'clear-status'}">${escapeHTML(detail.detection_result)}</span><strong>Risk score ${detail.risk_score}/100</strong><p>${reasons.length?reasons.map(escapeHTML).join(' '):'No rule indicators were detected.'}</p></div><div class="endpoint-grid">${accountBlock('Sender',detail.sender_details)}${accountBlock('Receiver',detail.receiver_details)}</div><div class="investigation-grid"><div><h4>Local transaction network</h4>${renderTransactionNetwork(detail.network)}</div><div><h4>Relevant connected accounts</h4><p>${escapeHTML((detail.relevant_connected_accounts||[]).join(', ')||'None')}</p>${cycle.length?`<h4>Detected cycle path</h4><p>${escapeHTML(cycle.join(' → '))} → ${escapeHTML(cycle[0])}</p>`:''}</div></div>`}
async function showTransactionDetail(id){const detail=await api(`/api/transaction/${id}`);const panel=$('transaction-detail');panel.innerHTML=renderTransactionDetail(detail);panel.classList.remove('hidden');panel.scrollIntoView({behavior:'smooth',block:'start'});$('close-transaction-detail').addEventListener('click',()=>panel.classList.add('hidden'))}
async function loadNetwork(){const n=await api('/api/network');$('network-nodes').textContent=fmt(n.nodes);$('network-edges').textContent=fmt(n.edges);$('network-top').textContent=n.top_accounts[0]?.account||'—';const headers=[{key:'account',label:'Account'},{key:'incoming_connections',label:'Incoming'},{key:'outgoing_connections',label:'Outgoing'},{key:'total_connections',label:'Total'}];$('network-table').innerHTML=table(headers,n.top_accounts);populateAccounts('network-account')}
async function loadSuspicious(){const data=await api('/api/suspicious');const headers=[{key:'account',label:'Account'},{key:'incoming_connections',label:'Incoming'},{key:'outgoing_connections',label:'Outgoing'},{key:'total_connections',label:'Total'},{key:'incoming_amount',label:'Incoming amount',render:money},{key:'outgoing_amount',label:'Outgoing amount',render:money},{key:'investigation_score',label:'Score'},{key:'indicator',label:'Indicator',render:v=>`<span class="review">${v}</span>`}];$('suspicious-table').innerHTML=table(headers,data.accounts)}
async function loadEvaluation(){const data=await api('/api/evaluation');if(!data.available){document.querySelectorAll('.evaluation-note')[0].textContent=data.message;$('evaluation-accuracy').textContent='N/A';$('evaluation-precision').textContent='N/A';$('evaluation-recall').textContent='N/A';$('evaluation-f1').textContent='N/A';return}const percent=value=>`${(Number(value)*100).toFixed(2)}%`;$('evaluation-accuracy').textContent=percent(data.accuracy);$('evaluation-precision').textContent=percent(data.precision);$('evaluation-recall').textContent=percent(data.recall);$('evaluation-f1').textContent=percent(data.f1_score);$('evaluation-tn').textContent=fmt(data.true_negative);$('evaluation-fp').textContent=fmt(data.false_positive);$('evaluation-fn').textContent=fmt(data.false_negative);$('evaluation-tp').textContent=fmt(data.true_positive);$('evaluation-total').textContent=`${fmt(data.total_evaluated)} holdout records`;$('evaluation-detector').textContent=`Detector: ${data.detector}`;document.querySelectorAll('.evaluation-note')[0].textContent=`Metrics compare rule-based predictions with actual labels on the later 20% of the timeline, starting ${data.holdout_start}. The graph and thresholds use only the earlier ${fmt(data.training_transactions)} transactions.`;document.querySelectorAll('.evaluation-note')[1].textContent='These are retrospective holdout metrics, not proof of real-world performance; the detector is a transparent investigation aid, not a trained classifier.'}
async function populateAccounts(id){const accounts=await api('/api/accounts');$(id).innerHTML='<option value="">Select an account</option>'+accounts.map(a=>`<option>${a}</option>`).join('')}
function renderLocalNetwork(id, account, connected) {
  const box = $(id);
  box.innerHTML = '';
  [account, ...connected.slice(0, 12)].forEach((node, index, nodes) => {
    const element = document.createElement('span');
    const angle = (index - 1) * Math.PI * 2 / Math.max(nodes.length - 1, 1);
    element.className = `network-node ${index ? '' : 'center'}`;
    element.textContent = node;
    element.style.left = `${index ? 44 + 35 * Math.cos(angle) : 44}%`;
    element.style.top = `${index ? 42 + 32 * Math.sin(angle) : 42}%`;
    box.appendChild(element);
  });
}
async function inspectAccount(id) {
  const account = $(id).value;
  if (!account) return;
  const detail = await api(`/api/account/${encodeURIComponent(account)}`);
  if (id === 'network-account') return renderLocalNetwork('network-visual', account, detail.connected_accounts);
  $('account-detail').classList.remove('hidden');
  $('account-detail').innerHTML = `<div class="detail-grid">${[['Account',detail.account],['Transactions',fmt(detail.transactions)],['Incoming',fmt(detail.incoming)],['Outgoing',fmt(detail.outgoing)],['Incoming amount',money(detail.incoming_amount)],['Outgoing amount',money(detail.outgoing_amount)],['Total amount',money(detail.total_amount)],['Laundering transactions',fmt(detail.laundering_transactions)]].map(([label,value])=>`<div class="detail-card"><span>${label}</span><strong>${value}</strong></div>`).join('')}</div><div class="panel local-network"><h3>Small account network</h3><div id="account-network" class="network-visual"></div></div><div class="panel table-panel"><div class="panel-heading"><h3>Related transactions</h3></div>${table(transactionHeaders(),detail.related_transactions)}</div>`;
  renderLocalNetwork('account-network', account, detail.connected_accounts);
}
async function addTransaction(event) {
  event.preventDefault();
  const form = event.currentTarget;
  if (form.dataset.submitting === 'true') return;
  form.dataset.submitting = 'true';
  const button = form.querySelector('button[type="submit"]');
  const success = $('transaction-success');
  const errorMessage = $('transaction-error');
  const resultPanel = $('transaction-result');
  success.classList.add('hidden');
  errorMessage.classList.add('hidden');
  resultPanel.classList.add('hidden');
  button.disabled = true;
  hideError();
  try {
    const payload = Object.fromEntries(new FormData(form));
    const response = await fetch('/api/add-transaction', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload)
    });
    let result = null;
    try { result = await response.json(); } catch { result = null; }
    if (!response.ok) {
      throw new Error(result?.error || `The server did not confirm the transaction (HTTP ${response.status}).`);
    }
    if (!result || typeof result !== 'object' || result.success !== true || result.saved !== true) {
      throw new Error(result?.error || 'The server did not confirm the transaction.');
    }
    const transaction = result.transaction;
    const assessment = result.assessment;
    const transactionId = result.transaction_id;
    if ((typeof transactionId !== 'string' && typeof transactionId !== 'number')
        || String(transactionId).trim() === '') {
      throw new Error('The server reported success but did not return a transaction ID. It may already be saved; check Transactions before submitting this transfer again.');
    }
    if (!assessment || typeof assessment !== 'object' || assessment.completed !== true
        || typeof assessment.status !== 'string' || !assessment.status.trim()) {
      throw new Error('The transaction may have been saved, but its assessment response was incomplete. Check Transactions before submitting this transfer again.');
    }
    const indicators = Array.isArray(assessment.indicators) ? assessment.indicators
      : Array.isArray(assessment.reasons) ? assessment.reasons : [];
    const riskScore = Number(assessment.risk_score);
    const scoreDisplay = Number.isFinite(riskScore) ? `<strong>Risk score ${riskScore}/100</strong>` : '';
    const explanation = typeof assessment.explanation === 'string' ? assessment.explanation : '';
    resultPanel.innerHTML = `<div class="panel-heading"><div><h3>Automatic transaction assessment</h3><p>Transaction ID: ${escapeHTML(transactionId)} · Rule-based risk score, not a model probability</p></div></div><div class="transaction-summary"><span class="${assessment.detection_result === 'Requires Review' ? 'review' : 'clear-status'}">${escapeHTML(assessment.status)}</span>${scoreDisplay}<p>${escapeHTML(explanation || 'No explanation was returned.')}</p></div><p>Sender: ${escapeHTML(transaction?.sender_account || '—')} · Receiver: ${escapeHTML(transaction?.receiver_account || '—')}</p>${transaction && Number.isFinite(Number(transaction.amount)) ? `<p>Amount: ${money(transaction.amount)} ${escapeHTML(transaction.currency || '')}</p>` : ''}<h4>Detected indicators</h4>${indicators.length ? `<ul>${indicators.map(reason => `<li>${escapeHTML(reason)}</li>`).join('')}</ul>` : '<p>No configured indicators were detected from the available history.</p>'}<p class="muted">The actual laundering label is unknown; no detected indicators do not prove a transaction is legitimate.</p>`;
    resultPanel.classList.remove('hidden');
    form.reset();
    success.textContent = result.message || 'Transaction added successfully.';
    success.classList.remove('hidden');
    transactionState.page = 1;
    datasetState.page = 1;
    const refreshResults = await Promise.allSettled([
      loadDashboard(), loadDataset(), loadTransactions(), loadNetwork(),
      loadSuspicious(), populateAccounts('account-select')
    ]);
    const refreshError = refreshResults.find(item => item.status === 'rejected');
    if (refreshError) {
      errorMessage.textContent = 'Transaction saved, but some dashboard views could not refresh. Reload the page to see the latest data.';
      errorMessage.classList.remove('hidden');
    }
  } catch (error) {
    errorMessage.textContent = error instanceof TypeError
      ? 'No confirmation was received. Check the transaction list before retrying to avoid a duplicate.'
      : error.message;
    errorMessage.classList.remove('hidden');
  } finally {
    form.dataset.submitting = 'false';
    button.disabled = false;
  }
}
const loaders={dashboard:loadDashboard,'add-transaction':()=>Promise.resolve(),dataset:loadDataset,transactions:loadTransactions,network:loadNetwork,suspicious:loadSuspicious,evaluation:loadEvaluation,account:()=>populateAccounts('account-select')};
document.querySelectorAll('.nav-item').forEach(button=>button.addEventListener('click',async()=>{document.querySelectorAll('.nav-item').forEach(b=>b.classList.remove('active'));button.classList.add('active');document.querySelectorAll('.view').forEach(v=>v.classList.remove('active-view'));$(button.dataset.view).classList.add('active-view');$('page-title').textContent=button.textContent.trim();hideError();try{await loaders[button.dataset.view]()}catch(e){showError(e)}}));
$('apply-filters').addEventListener('click',()=>{transactionState.page=1;loadTransactions().catch(showError)});$('filter-search').addEventListener('keydown',event=>{if(event.key==='Enter'){transactionState.page=1;loadTransactions().catch(showError)}});$('transaction-table').addEventListener('click',event=>{const button=event.target.closest('.transaction-select');if(button)showTransactionDetail(button.dataset.id).catch(showError)});$('transaction-previous').addEventListener('click',()=>{if(transactionState.page>1){transactionState.page--;loadTransactions().catch(showError)}});$('transaction-next').addEventListener('click',()=>{transactionState.page++;loadTransactions().catch(showError)});$('transaction-page-size').addEventListener('change',event=>{transactionState.page=1;transactionState.limit=Number(event.target.value);loadTransactions().catch(showError)});$('network-load').addEventListener('click',()=>inspectAccount('network-account').catch(showError));$('account-load').addEventListener('click',()=>inspectAccount('account-select').catch(showError));
['dataset-laundering','dataset-sort','dataset-direction','dataset-page-size'].forEach(id=>$(id).addEventListener('change',()=>{datasetState.page=1;if(id==='dataset-page-size')datasetState.limit=Number($(id).value);loadDataset().catch(showError)}));$('dataset-search').addEventListener('keydown',event=>{if(event.key==='Enter'){datasetState.page=1;loadDataset().catch(showError)}});$('dataset-previous').addEventListener('click',()=>{if(datasetState.page>1){datasetState.page--;loadDataset().catch(showError)}});$('dataset-next').addEventListener('click',()=>{datasetState.page++;loadDataset().catch(showError)});
$('transaction-form').addEventListener('submit',addTransaction);
loadDashboard().catch(showError);